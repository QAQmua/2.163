import SwiftUI

// MARK: - 1. 自动装配插座
final class AlbumWidgetPlugin: BaseWidgetPlugin {
    @MainActor override class func register() {
        WidgetRegistry.shared.registerAlbumWidget()
    }
}

// MARK: - 优雅的高斯模糊渐隐过渡引擎
struct BlurFadeTransition: ViewModifier {
    let isIdentity: Bool
    func body(content: Content) -> some View {
        content
            .opacity(isIdentity ? 1.0 : 0.0)
            .blur(radius: isIdentity ? 0.0 : 8.0)
            .scaleEffect(isIdentity ? 1.0 : 0.95)
    }
}

extension AnyTransition {
    static var blurFade: AnyTransition {
        .modifier(
            active: BlurFadeTransition(isIdentity: false),
            identity: BlurFadeTransition(isIdentity: true)
        )
    }
}

// MARK: - 2. 状态管理器 (2×2 规范)
@MainActor
final class AlbumWidgetManager: ObservableObject {
    static let shared = AlbumWidgetManager()
    
    nonisolated var sizeRows: Int { 2 }
    nonisolated var sizeCols: Int { 2 }
    
    // 桌面定位
    @Published var isAddedToDesktop: Bool { didSet { UserDefaults.standard.set(isAddedToDesktop, forKey: "W_AL_Added") } }
    @Published var widgetPage: Int { didSet { UserDefaults.standard.set(widgetPage, forKey: "W_AL_Page") } }
    @Published var widgetRow: Int { didSet { UserDefaults.standard.set(widgetRow, forKey: "W_AL_Row") } }
    @Published var widgetCol: Int { didSet { UserDefaults.standard.set(widgetCol, forKey: "W_AL_Col") } }
    
    // 外观基础
    @Published var bgColorMode: String { didSet { UserDefaults.standard.set(bgColorMode, forKey: "W_AL_BgMode") } }
    @Published var imageCornerRadius: Double { didSet { UserDefaults.standard.set(imageCornerRadius, forKey: "W_AL_ImgRadius") } }
    
    // 外边框线条配置 (最外圈)
    @Published var hasOuterBorder: Bool { didSet { UserDefaults.standard.set(hasOuterBorder, forKey: "W_AL_HasBorder") } }
    @Published var outerBorderColorHex: String { didSet { UserDefaults.standard.set(outerBorderColorHex, forKey: "W_AL_BorderColor") } }
    @Published var outerBorderWidth: Double { didSet { UserDefaults.standard.set(outerBorderWidth, forKey: "W_AL_BorderWidth") } }
    
    // 层数控制 (1, 2, 3)
    @Published var cardLayersCount: Int { didSet { UserDefaults.standard.set(cardLayersCount, forKey: "W_AL_LayerCount") } }
    
    // 当前处于最前排展示的卡片索引 (0, 1, 2)
    @Published var currentCardIndex: Int { didSet { UserDefaults.standard.set(currentCardIndex, forKey: "W_AL_CurIndex") } }
    
    // 每一层独立的标题名字
    @Published var title1: String { didSet { UserDefaults.standard.set(title1, forKey: "W_AL_Title1") } }
    @Published var title2: String { didSet { UserDefaults.standard.set(title2, forKey: "W_AL_Title2") } }
    @Published var title3: String { didSet { UserDefaults.standard.set(title3, forKey: "W_AL_Title3") } }
    
    // 每一层独立的图片数据
    @Published var image1Data: Data? {
        didSet { LocalImageStore.shared.replace(oldId: UserDefaults.standard.string(forKey: "W_AL_Img1"), with: image1Data) { UserDefaults.standard.set($0, forKey: "W_AL_Img1") } }
    }
    @Published var image2Data: Data? {
        didSet { LocalImageStore.shared.replace(oldId: UserDefaults.standard.string(forKey: "W_AL_Img2"), with: image2Data) { UserDefaults.standard.set($0, forKey: "W_AL_Img2") } }
    }
    @Published var image3Data: Data? {
        didSet { LocalImageStore.shared.replace(oldId: UserDefaults.standard.string(forKey: "W_AL_Img3"), with: image3Data) { UserDefaults.standard.set($0, forKey: "W_AL_Img3") } }
    }
    
    // 🌟 三层固定槽位的收窄边距
    @Published var card1Inset: Double { didSet { UserDefaults.standard.set(card1Inset, forKey: "W_AL_Card1Inset") } }
    @Published var card2Inset: Double { didSet { UserDefaults.standard.set(card2Inset, forKey: "W_AL_Card2Inset") } }
    @Published var card3Inset: Double { didSet { UserDefaults.standard.set(card3Inset, forKey: "W_AL_Card3Inset") } }
    
    // 每层卡片底色
    @Published var card1ColorHex: String { didSet { UserDefaults.standard.set(card1ColorHex, forKey: "W_AL_Card1Color") } }
    @Published var card2ColorHex: String { didSet { UserDefaults.standard.set(card2ColorHex, forKey: "W_AL_Card2Color") } }
    @Published var card3ColorHex: String { didSet { UserDefaults.standard.set(card3ColorHex, forKey: "W_AL_Card3Color") } }
    
    // 描边配置
    @Published var hasCard1Border: Bool { didSet { UserDefaults.standard.set(hasCard1Border, forKey: "W_AL_HasC1Border") } }
    @Published var card1BorderColorHex: String { didSet { UserDefaults.standard.set(card1BorderColorHex, forKey: "W_AL_C1BorderColor") } }
    @Published var card1BorderWidth: Double { didSet { UserDefaults.standard.set(card1BorderWidth, forKey: "W_AL_C1BorderWidth") } }
    
    @Published var hasCard2Border: Bool { didSet { UserDefaults.standard.set(hasCard2Border, forKey: "W_AL_HasC2Border") } }
    @Published var card2BorderColorHex: String { didSet { UserDefaults.standard.set(card2BorderColorHex, forKey: "W_AL_C2BorderColor") } }
    @Published var card2BorderWidth: Double { didSet { UserDefaults.standard.set(card2BorderWidth, forKey: "W_AL_C2BorderWidth") } }
    
    @Published var hasCard3Border: Bool { didSet { UserDefaults.standard.set(hasCard3Border, forKey: "W_AL_HasC3Border") } }
    @Published var card3BorderColorHex: String { didSet { UserDefaults.standard.set(card3BorderColorHex, forKey: "W_AL_C3BorderColor") } }
    @Published var card3BorderWidth: Double { didSet { UserDefaults.standard.set(card3BorderWidth, forKey: "W_AL_C3BorderWidth") } }
    
    // 每层卡片的胶囊栏、圆形按钮、文字与图标配色
    @Published var capsule1BgColorHex: String { didSet { UserDefaults.standard.set(capsule1BgColorHex, forKey: "W_AL_Cap1Color") } }
    @Published var circle1BgColorHex: String { didSet { UserDefaults.standard.set(circle1BgColorHex, forKey: "W_AL_Cir1Color") } }
    @Published var text1ColorHex: String { didSet { UserDefaults.standard.set(text1ColorHex, forKey: "W_AL_Txt1Color") } }
    @Published var icon1ColorHex: String { didSet { UserDefaults.standard.set(icon1ColorHex, forKey: "W_AL_Ico1Color") } }
    
    @Published var capsule2BgColorHex: String { didSet { UserDefaults.standard.set(capsule2BgColorHex, forKey: "W_AL_Cap2Color") } }
    @Published var circle2BgColorHex: String { didSet { UserDefaults.standard.set(circle2BgColorHex, forKey: "W_AL_Cir2Color") } }
    @Published var text2ColorHex: String { didSet { UserDefaults.standard.set(text2ColorHex, forKey: "W_AL_Txt2Color") } }
    @Published var icon2ColorHex: String { didSet { UserDefaults.standard.set(icon2ColorHex, forKey: "W_AL_Ico2Color") } }
    
    @Published var capsule3BgColorHex: String { didSet { UserDefaults.standard.set(capsule3BgColorHex, forKey: "W_AL_Cap3Color") } }
    @Published var circle3BgColorHex: String { didSet { UserDefaults.standard.set(circle3BgColorHex, forKey: "W_AL_Cir3Color") } }
    @Published var text3ColorHex: String { didSet { UserDefaults.standard.set(text3ColorHex, forKey: "W_AL_Txt3Color") } }
    @Published var icon3ColorHex: String { didSet { UserDefaults.standard.set(icon3ColorHex, forKey: "W_AL_Ico3Color") } }
    
    func switchToNextCard() {
        let total = max(1, cardLayersCount)
        currentCardIndex = (currentCardIndex + 1) % total
    }
    
    func switchToCard(to index: Int) {
        let total = max(1, cardLayersCount)
        if index >= 0 && index < total {
            currentCardIndex = index
        }
    }
    
    init() {
        let ud = UserDefaults.standard
        self.isAddedToDesktop = ud.bool(forKey: "W_AL_Added")
        self.widgetPage = ud.integer(forKey: "W_AL_Page")
        self.widgetRow = ud.object(forKey: "W_AL_Row") != nil ? ud.integer(forKey: "W_AL_Row") : 2
        self.widgetCol = ud.integer(forKey: "W_AL_Col") > 0 ? 2 : 0
        
        self.bgColorMode = ud.string(forKey: "W_AL_BgMode") ?? "default"
        self.imageCornerRadius = ud.object(forKey: "W_AL_ImgRadius") != nil ? ud.double(forKey: "W_AL_ImgRadius") : 14.0
        
        self.hasOuterBorder = ud.object(forKey: "W_AL_HasBorder") != nil ? ud.bool(forKey: "W_AL_HasBorder") : false
        self.outerBorderColorHex = ud.string(forKey: "W_AL_BorderColor") ?? "#E5E5EA"
        self.outerBorderWidth = ud.object(forKey: "W_AL_BorderWidth") != nil ? ud.double(forKey: "W_AL_BorderWidth") : 1.0
        
        self.cardLayersCount = ud.object(forKey: "W_AL_LayerCount") != nil ? ud.integer(forKey: "W_AL_LayerCount") : 3
        self.currentCardIndex = ud.integer(forKey: "W_AL_CurIndex")
        
        let legacyTitle = ud.string(forKey: "W_AL_Title") ?? "album"
        self.title1 = ud.string(forKey: "W_AL_Title1") ?? legacyTitle
        self.title2 = ud.string(forKey: "W_AL_Title2") ?? "album 02"
        self.title3 = ud.string(forKey: "W_AL_Title3") ?? "album 03"
        
        self.card1Inset = ud.object(forKey: "W_AL_Card1Inset") != nil ? ud.double(forKey: "W_AL_Card1Inset") : 10.0
        self.card2Inset = ud.object(forKey: "W_AL_Card2Inset") != nil ? ud.double(forKey: "W_AL_Card2Inset") : 13.5
        self.card3Inset = ud.object(forKey: "W_AL_Card3Inset") != nil ? ud.double(forKey: "W_AL_Card3Inset") : 17.0
        
        self.card1ColorHex = ud.string(forKey: "W_AL_Card1Color") ?? "#F2F2F7"
        self.card2ColorHex = ud.string(forKey: "W_AL_Card2Color") ?? "#E0E0E6"
        self.card3ColorHex = ud.string(forKey: "W_AL_Card3Color") ?? "#D0D0D6"
        
        self.hasCard1Border = ud.bool(forKey: "W_AL_HasC1Border")
        self.card1BorderColorHex = ud.string(forKey: "W_AL_C1BorderColor") ?? "#E5E5EA"
        self.card1BorderWidth = ud.object(forKey: "W_AL_C1BorderWidth") != nil ? ud.double(forKey: "W_AL_C1BorderWidth") : 0.8
        
        self.hasCard2Border = ud.bool(forKey: "W_AL_HasC2Border")
        self.card2BorderColorHex = ud.string(forKey: "W_AL_C2BorderColor") ?? "#D1D1D6"
        self.card2BorderWidth = ud.object(forKey: "W_AL_C2BorderWidth") != nil ? ud.double(forKey: "W_AL_C2BorderWidth") : 0.8
        
        self.hasCard3Border = ud.bool(forKey: "W_AL_HasC3Border")
        self.card3BorderColorHex = ud.string(forKey: "W_AL_C3BorderColor") ?? "#C7C7CC"
        self.card3BorderWidth = ud.object(forKey: "W_AL_C3BorderWidth") != nil ? ud.double(forKey: "W_AL_C3BorderWidth") : 0.8
        
        self.capsule1BgColorHex = ud.string(forKey: "W_AL_Cap1Color") ?? "#FFFFFF"
        self.circle1BgColorHex = ud.string(forKey: "W_AL_Cir1Color") ?? "#FFFFFF"
        self.text1ColorHex = ud.string(forKey: "W_AL_Txt1Color") ?? "#000000"
        self.icon1ColorHex = ud.string(forKey: "W_AL_Ico1Color") ?? "#000000"
        
        self.capsule2BgColorHex = ud.string(forKey: "W_AL_Cap2Color") ?? "#FFFFFF"
        self.circle2BgColorHex = ud.string(forKey: "W_AL_Cir2Color") ?? "#FFFFFF"
        self.text2ColorHex = ud.string(forKey: "W_AL_Txt2Color") ?? "#000000"
        self.icon2ColorHex = ud.string(forKey: "W_AL_Ico2Color") ?? "#000000"
        
        self.capsule3BgColorHex = ud.string(forKey: "W_AL_Cap3Color") ?? "#FFFFFF"
        self.circle3BgColorHex = ud.string(forKey: "W_AL_Cir3Color") ?? "#FFFFFF"
        self.text3ColorHex = ud.string(forKey: "W_AL_Txt3Color") ?? "#000000"
        self.icon3ColorHex = ud.string(forKey: "W_AL_Ico3Color") ?? "#000000"
        
        let legacyId = ud.string(forKey: "W_AL_Img")
        if let id1 = ud.string(forKey: "W_AL_Img1") { self.image1Data = LocalImageStore.shared.load(id: id1) }
        else if let lId = legacyId { self.image1Data = LocalImageStore.shared.load(id: lId) }
        
        if let id2 = ud.string(forKey: "W_AL_Img2") { self.image2Data = LocalImageStore.shared.load(id: id2) }
        if let id3 = ud.string(forKey: "W_AL_Img3") { self.image3Data = LocalImageStore.shared.load(id: id3) }
    }
}

extension AlbumWidgetManager: @preconcurrency DesktopWidgetManager {}

// MARK: - 3. 文本按 1-3 字词分段波浪淡入对焦组件
struct ChunkBlurRevealText: View {
    let text: String
    let font: Font
    let color: Color
    let triggerID: AnyHashable
    
    @State private var revealedIndices: Set<Int> = []
    
    private var chunks: [String] {
        splitIntoChunks(text)
    }
    
    var body: some View {
        HStack(spacing: 0) {
            ForEach(Array(chunks.enumerated()), id: \.offset) { index, chunk in
                let isRevealed = revealedIndices.contains(index)
                Text(chunk)
                    .font(font)
                    .foregroundColor(color)
                    .opacity(isRevealed ? 1.0 : 0.0)
                    .blur(radius: isRevealed ? 0.0 : 4.0)
                    .animation(.easeOut(duration: 0.28).delay(Double(index) * 0.06), value: isRevealed)
            }
        }
        .onAppear {
            startAnimation()
        }
        .onChange(of: triggerID) { _, _ in
            startAnimation()
        }
    }
    
    private func startAnimation() {
        revealedIndices.removeAll()
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.02) {
            revealedIndices = Set(0..<chunks.count)
        }
    }
    
    private func splitIntoChunks(_ string: String) -> [String] {
        guard !string.isEmpty else { return [] }
        var result: [String] = []
        let chars = Array(string)
        var i = 0
        while i < chars.count {
            let remaining = chars.count - i
            let chunkSize = (remaining == 4) ? 2 : min(3, remaining)
            let chunk = String(chars[i..<i + chunkSize])
            result.append(chunk)
            i += chunkSize
        }
        return result.isEmpty ? [string] : result
    }
}

// MARK: - 4. 2×2 精密小组件视图
@MainActor
struct AlbumWidget2x2View: View {
    @ObservedObject var manager = AlbumWidgetManager.shared
    var showDashedBorder: Bool = false
    @ObservedObject var appearance = SystemAppearance.shared
    @Environment(\.colorScheme) var colorScheme
    
    @State private var isTransitioning: Bool = false
    @State private var plusRotation: Double = 0
    
    private var isDark: Bool { manager.bgColorMode == "black" || (manager.bgColorMode == "default" && colorScheme == .dark) }
    
    private var baseBgColor: Color {
        if manager.bgColorMode == "transparent" { return .clear }
        if manager.bgColorMode == "white" { return .white }
        if manager.bgColorMode == "black" { return .black }
        return isDark ? .black : .white
    }
    
    private var mainCardTopPadding: CGFloat {
        switch manager.cardLayersCount {
        case 1: return 6.0
        case 2: return 9.5
        default: return 13.0
        }
    }
    
    private func cardColor(for index: Int) -> Color {
        switch index {
        case 0: return !manager.card1ColorHex.isEmpty ? Color(hex: manager.card1ColorHex) : (isDark ? Color(hex: "#2C2C2E") : Color(hex: "#F2F2F7"))
        case 1: return !manager.card2ColorHex.isEmpty ? Color(hex: manager.card2ColorHex) : (isDark ? Color(hex: "#242428") : Color(hex: "#E0E0E6"))
        default: return !manager.card3ColorHex.isEmpty ? Color(hex: manager.card3ColorHex) : (isDark ? Color(hex: "#1A1A1E") : Color(hex: "#D0D0D6"))
        }
    }
    
    private func hasBorder(for index: Int) -> Bool {
        switch index {
        case 0: return manager.hasCard1Border
        case 1: return manager.hasCard2Border
        default: return manager.hasCard3Border
        }
    }
    
    private func borderColor(for index: Int) -> Color {
        switch index {
        case 0: return Color(hex: manager.card1BorderColorHex)
        case 1: return Color(hex: manager.card2BorderColorHex)
        default: return Color(hex: manager.card3BorderColorHex)
        }
    }
    
    private func borderWidth(for index: Int) -> Double {
        switch index {
        case 0: return manager.card1BorderWidth
        case 1: return manager.card2BorderWidth
        default: return manager.card3BorderWidth
        }
    }
    
    private func cardTitle(for index: Int) -> String {
        switch index {
        case 0: return manager.title1
        case 1: return manager.title2
        default: return manager.title3
        }
    }
    
    private func cardImage(for index: Int) -> Data? {
        switch index {
        case 0: return manager.image1Data
        case 1: return manager.image2Data
        default: return manager.image3Data
        }
    }
    
    private func capsuleBg(for index: Int) -> Color {
        let hex = index == 0 ? manager.capsule1BgColorHex : (index == 1 ? manager.capsule2BgColorHex : manager.capsule3BgColorHex)
        return !hex.isEmpty ? Color(hex: hex) : (isDark ? Color(hex: "#3A3A3C") : .white)
    }
    
    private func circleBg(for index: Int) -> Color {
        let hex = index == 0 ? manager.circle1BgColorHex : (index == 1 ? manager.circle2BgColorHex : manager.circle3BgColorHex)
        return !hex.isEmpty ? Color(hex: hex) : (isDark ? Color(hex: "#3A3A3C") : .white)
    }
    
    private func textCol(for index: Int) -> Color {
        let hex = index == 0 ? manager.text1ColorHex : (index == 1 ? manager.text2ColorHex : manager.text3ColorHex)
        return !hex.isEmpty ? Color(hex: hex) : (isDark ? .white : .black)
    }
    
    private func iconCol(for index: Int) -> Color {
        let hex = index == 0 ? manager.icon1ColorHex : (index == 1 ? manager.icon2ColorHex : manager.icon3ColorHex)
        return !hex.isEmpty ? Color(hex: hex) : (isDark ? .white : .black)
    }
    
    var body: some View {
        let s = uiScale
        let total = max(1, manager.cardLayersCount)
        
        ZStack(alignment: .top) {
            baseBgColor
            
            ForEach(0..<total, id: \.self) { i in
                let depth = (i - manager.currentCardIndex + total) % total
                singleCascadeCard(index: i, depth: depth, s: s)
            }
            
            if manager.hasOuterBorder {
                RoundedRectangle(cornerRadius: 22 * s, style: .continuous)
                    .stroke(Color(hex: manager.outerBorderColorHex), lineWidth: CGFloat(manager.outerBorderWidth) * s)
                    .allowsHitTesting(false)
            }
            
            if manager.bgColorMode == "transparent" && showDashedBorder {
                RoundedRectangle(cornerRadius: 22 * s, style: .continuous)
                    .stroke(Color.secondary.opacity(0.4), style: StrokeStyle(lineWidth: 1 * s, dash: [5 * s, 4 * s]))
                    .allowsHitTesting(false)
            }
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .clipShape(RoundedRectangle(cornerRadius: 22 * s, style: .continuous))
        .animation(.spring(response: 0.40, dampingFraction: 0.78), value: manager.currentCardIndex)
        .animation(.spring(response: 0.40, dampingFraction: 0.78), value: manager.cardLayersCount)
        .onChange(of: manager.currentCardIndex) { _, _ in
            triggerVisualTransition()
        }
    }
    
    @ViewBuilder
    private func singleCascadeCard(index: Int, depth: Int, s: CGFloat) -> some View {
        let isFront = (depth == 0)
        
        let slotInset: CGFloat = {
            switch depth {
            case 0: return CGFloat(manager.card1Inset)
            case 1: return CGFloat(manager.card2Inset)
            default: return CGFloat(manager.card3Inset)
            }
        }()
        
        let hPadding: CGFloat = slotInset * s
        let bPadding: CGFloat = slotInset * s
        
        let topPadding: CGFloat = {
            switch depth {
            case 0: return mainCardTopPadding * s
            case 1: return (manager.cardLayersCount >= 3 ? 8.0 : 4.0) * s
            default: return 4.0 * s
            }
        }()
        
        let cornerRadius: CGFloat = {
            switch depth {
            case 0: return 17.0 * s
            case 1: return 16.0 * s
            default: return 15.0 * s
            }
        }()
        
        let cardZIndex = Double(10 - depth * 4)
        
        ZStack(alignment: .top) {
            RoundedRectangle(cornerRadius: cornerRadius, style: .continuous)
                .fill(cardColor(for: index))
                .overlay(
                    Group {
                        if hasBorder(for: index) {
                            RoundedRectangle(cornerRadius: cornerRadius, style: .continuous)
                                .stroke(borderColor(for: index), lineWidth: CGFloat(borderWidth(for: index)) * s)
                        }
                    }
                )
            
            VStack(spacing: 6 * s) {
                HStack(spacing: 6.5 * s) {
                    HStack(alignment: .center, spacing: 0) {
                        if isFront {
                            ChunkBlurRevealText(
                                text: cardTitle(for: index),
                                font: .system(size: 12 * s, weight: .semibold, design: .rounded),
                                color: textCol(for: index),
                                triggerID: manager.currentCardIndex
                            )
                            .lineLimit(1)
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .padding(.leading, 2 * s)
                        } else {
                            Text(cardTitle(for: index))
                                .font(.system(size: 12 * s, weight: .semibold, design: .rounded))
                                .foregroundColor(textCol(for: index))
                                .lineLimit(1)
                                .frame(maxWidth: .infinity, alignment: .leading)
                                .padding(.leading, 2 * s)
                        }
                        
                        Button(action: {
                            handleCascadeCardAction()
                        }) {
                            Image(systemName: "plus")
                                .font(.system(size: 12.5 * s, weight: .semibold))
                                .foregroundColor(iconCol(for: index))
                                .rotationEffect(.degrees(plusRotation))
                                .frame(width: 22 * s, height: 22 * s)
                                .contentShape(Rectangle())
                        }
                        .buttonStyle(.plain)
                    }
                    .padding(.leading, 10 * s)
                    .padding(.trailing, 4 * s)
                    .frame(height: 28 * s)
                    .background(capsuleBg(for: index))
                    .clipShape(Capsule())
                    
                    ZStack {
                        circleBg(for: index)
                        Image(systemName: "square.on.square")
                            .font(.system(size: 11.5 * s, weight: .semibold))
                            .foregroundColor(iconCol(for: index))
                            .offset(y: -0.5 * s)
                    }
                    .frame(width: 28 * s, height: 28 * s)
                    .clipShape(Circle())
                }
                
                // 🌟 大卡片主图片渲染区：加上高质感高斯模糊渐隐过渡
                Color.clear
                    .overlay(
                        ZStack {
                            if let data = cardImage(for: index), let uiImg = ImageBitmapCache.shared.image(from: data) {
                                Image(uiImage: uiImg)
                                    .resizable()
                                    .scaledToFill()
                                    .transition(.blurFade)
                            } else {
                                ZStack {
                                    capsuleBg(for: index)
                                    VStack(spacing: 4 * s) {
                                        Image(systemName: "photo.on.rectangle.angled")
                                            .font(.system(size: 22 * s))
                                        Text("点击编辑设置第 \(index + 1) 张插画".tr)
                                            .font(.system(size: 9.5 * s, weight: .medium))
                                    }
                                    .foregroundColor(Color(hex: "#999999"))
                                }
                                .transition(.opacity)
                            }
                        }
                    )
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
                    .background(capsuleBg(for: index))
                    .clipped()
                    .clipShape(RoundedRectangle(cornerRadius: CGFloat(manager.imageCornerRadius) * s, style: .continuous))
            }
            .padding(6 * s)
            .allowsHitTesting(isFront)
        }
        .clipShape(RoundedRectangle(cornerRadius: cornerRadius, style: .continuous))
        .padding(.horizontal, hPadding)
        .padding(.top, topPadding)
        .padding(.bottom, bPadding)
        .zIndex(cardZIndex)
        .scaleEffect(isTransitioning ? (isFront ? 0.965 : 1.01) : 1.0)
    }
    
    private func triggerVisualTransition() {
        withAnimation(.spring(response: 0.38, dampingFraction: 0.70)) {
            plusRotation += 90
        }
        withAnimation(.spring(response: 0.30, dampingFraction: 0.70)) {
            isTransitioning = true
        }
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.20) {
            withAnimation(.spring(response: 0.32, dampingFraction: 0.72)) {
                isTransitioning = false
            }
        }
    }
    
    private func handleCascadeCardAction() {
        UIImpactFeedbackGenerator(style: .medium).impactOccurred()
        withAnimation(.spring(response: 0.40, dampingFraction: 0.78)) {
            manager.switchToNextCard()
        }
    }
}

// MARK: - 5. 注册中心连接
extension WidgetRegistry {
    func registerAlbumWidget() {
        let mgr = AlbumWidgetManager.shared
        let s = uiScale
        registerWidget(
            id: "album_card",
            title: "相册插画",
            subtitle: "带有顶部胶囊栏的精美相册画框",
            badge: "2×2",
            manager: mgr,
            desktopView: { AlbumWidget2x2View(manager: mgr) },
            previewView: { AlbumWidget2x2View(manager: mgr).frame(width: 160 * s, height: 160 * s) },
            editSheetView: { show in EditAlbumWidgetSheet(isPresented: show) }
        )
    }
}
