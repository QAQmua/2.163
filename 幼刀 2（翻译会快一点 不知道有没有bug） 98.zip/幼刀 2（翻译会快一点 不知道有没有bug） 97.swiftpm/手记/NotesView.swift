import SwiftUI

final class NotesAppPlugin: BaseAppPlugin {
    override class var id: String { "notes" }
    override class var name: String { "手记" }
    override class var icon: String { "note.text" }
    override class var colorName: String { "orange" }
    override class func buildView(show: Binding<Bool>) -> AnyView {
        AnyView(NotesView(show: show))
    }
}

struct NotesView: View {
    @Binding var show: Bool
    @ObservedObject var appearance = SystemAppearance.shared 
    @ObservedObject var lang = LanguageManager.shared
    
    var body: some View {
        NavigationStack {
            List {
                Section {
                    Text("第一篇手记：记录今天的灵感".tr)
                        .font(.system(size: 16, weight: appearance.systemFontWeight))
                    Text("第二篇手记：代码重构计划".tr)
                        .font(.system(size: 16, weight: appearance.systemFontWeight))
                }
            }
            .listStyle(.insetGrouped)
            .navigationTitle(lang.tr("app_notes"))
            .navigationBarTitleDisplayMode(.large)
            .background(Color(UIColor.systemBackground))
        }
        .preferredColorScheme(appearance.colorScheme)
        .simultaneousGesture(
            DragGesture(minimumDistance: 15).onEnded { value in
                if value.translation.width > 50 && abs(value.translation.width) > abs(value.translation.height) {
                    UIImpactFeedbackGenerator(style: .light).impactOccurred()
                    withAnimation(.spring(response: 0.32, dampingFraction: 0.86)) { show = false }
                }
            }
        )
    }
}
