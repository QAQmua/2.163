// 📄 文件路径：信息/MessagesNetworkEngine.swift
import SwiftUI
import Foundation

// MARK: - 跨设备实时传输数据包协议 (Codable)
public enum IMMessagePacketType: String, Codable {
    case text           // 文本/富媒体消息
    case image          // 压缩图片消息
    case tapback        // 气泡点按回应 (❤️ 👍 👎 😂 ‼️ ❓)
    case typing         // 正在输入状态同步
    case readReceipt    // 已读回执同步
}

public struct IMNetworkPacket: Codable, Identifiable {
    public var id: String               // 消息唯一 UUID
    public var packetType: IMMessagePacketType
    public var senderID: String         // 发送方本机号码 (如 "839-201")
    public var senderName: String       // 发送方昵称
    public var senderAvatarBase64: String? // 发送方头像微缩图
    public var targetID: String         // 接收方号码
    public var textContent: String?     // 文字内容
    public var imageBase64: String?     // 图片数据 Base64
    public var replyToID: String?       // 引用回复的目标消息 ID
    public var replyPreview: String?    // 引用回复的文本预览
    public var tapbackSymbol: String?   // 点按回应符号
    public var sendEffect: String?      // 发送特效 ("slam", "loud", "gentle", "invisible")
    public var isTyping: Bool?          // 是否正在输入
    public var timestamp: TimeInterval  // 发送时间戳
}

// MARK: - Apple 原生 URLSessionWebSocketTask 全球异地实时通信引擎 (MQTT over WSS)
@MainActor
public final class MessagesNetworkEngine: ObservableObject {
    public static let shared = MessagesNetworkEngine()
    
    @Published public private(set) var isConnected: Bool = false
    @Published public private(set) var connectionStatusText: String = "正在连接 iMessage 云端..."
    
    private var webSocketTask: URLSessionWebSocketTask?
    private var pingTimer: Timer?
    private var reconnectTask: Task<Void, Never>?
    private var pendingQueue: [IMNetworkPacket] = []
    
    // 多节点高可用列表，防止单一节点被运营商拦截
    private let brokerURLs = [
        "wss://broker.emqx.io:8084/mqtt",
        "wss://broker.hivemq.com:8884/mqtt",
        "wss://test.mosquitto.org:8081"
    ]
    private var currentBrokerIndex: Int = 0
    
    // 回调给 ViewModel 处理收到的实时数据包
    public var onReceivePacket: ((IMNetworkPacket) -> Void)?
    
    // 专属命名空间前缀
    private let topicPrefix = "youdao_ios27_imessage_v1/peer/"
    private var currentSubscribedID: String = ""
    
    private init() {}
    
    // MARK: - 启动并订阅本机专属号码信道
    public func connect(myDeviceID: String) {
        let cleanID = Self.normalizeID(myDeviceID)
        guard !cleanID.isEmpty else { return }
        
        if isConnected && currentSubscribedID == cleanID { return }
        currentSubscribedID = cleanID
        
        disconnect()
        connectionStatusText = "正在连接 iMessage 云端..."
        
        let urlStr = brokerURLs[currentBrokerIndex % brokerURLs.count]
        guard let url = URL(string: urlStr) else { return }
        var request = URLRequest(url: url)
        request.timeoutInterval = 8
        request.setValue("mqtt", forHTTPHeaderField: "Sec-WebSocket-Protocol")
        
        let session = URLSession(configuration: .default)
        let task = session.webSocketTask(with: request)
        self.webSocketTask = task
        task.resume()
        
        // 先开启监听循环，等待服务器返回 0x20 (CONNACK) 确认帧
        receiveLoop()
        
        Task {
            do {
                let clientID = "yd_im_\(cleanID)_\(Int.random(in: 10000...99999))"
                let connectData = buildMQTTConnectPacket(clientID: clientID)
                try await task.send(.data(connectData))
            } catch {
                handleConnectionFailure()
            }
        }
    }
    
    // 收到服务器 CONNACK (0x20) 握手确认后再订阅收件箱并冲刷待发消息
    private func onHandshakeConfirmed() {
        Task {
            guard let task = webSocketTask else { return }
            do {
                let myTopic = topicPrefix + currentSubscribedID
                let subscribeData = buildMQTTSubscribePacket(topic: myTopic, packetID: 1)
                try await task.send(.data(subscribeData))
                
                self.isConnected = true
                self.connectionStatusText = "iMessage 云端已就绪"
                
                startPingLoop()
                flushPendingQueue()
            } catch {
                handleConnectionFailure()
            }
        }
    }
    
    public func disconnect() {
        pingTimer?.invalidate()
        pingTimer = nil
        reconnectTask?.cancel()
        reconnectTask = nil
        webSocketTask?.cancel(with: .goingAway, reason: nil)
        webSocketTask = nil
        isConnected = false
    }
    
    // MARK: - 发送数据包给异地设备
    public func sendPacket(_ packet: IMNetworkPacket) {
        let targetClean = Self.normalizeID(packet.targetID)
        guard !targetClean.isEmpty else { return }
        
        // 支持单机输入自己本机号自发自收测试
        if targetClean == currentSubscribedID {
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.15) {
                self.onReceivePacket?(packet)
            }
            return
        }
        
        guard isConnected, let task = webSocketTask else {
            if packet.packetType == .text || packet.packetType == .image || packet.packetType == .tapback {
                pendingQueue.append(packet)
            }
            connect(myDeviceID: currentSubscribedID)
            return
        }
        
        guard let jsonData = try? JSONEncoder().encode(packet) else { return }
        let targetTopic = topicPrefix + targetClean
        let publishPacket = buildMQTTPublishPacket(topic: targetTopic, payload: jsonData)
        
        task.send(.data(publishPacket)) { [weak self] error in
            if error != nil {
                Task { @MainActor in
                    if packet.packetType == .text || packet.packetType == .image || packet.packetType == .tapback {
                        self?.pendingQueue.append(packet)
                    }
                    self?.handleConnectionFailure()
                }
            }
        }
    }
    
    private func flushPendingQueue() {
        guard isConnected, !pendingQueue.isEmpty else { return }
        let items = pendingQueue
        pendingQueue.removeAll()
        for pkt in items {
            sendPacket(pkt)
        }
    }
    
    private func handleConnectionFailure() {
        isConnected = false
        connectionStatusText = "云端重连中..."
        currentBrokerIndex += 1
        scheduleReconnect()
    }
    
    // 标准化号码格式（去除空格与短横线，确保输入 "839-201" 和 "839201" 都能互通）
    public static func normalizeID(_ raw: String) -> String {
        return raw.trimmingCharacters(in: .whitespacesAndNewlines)
            .replacingOccurrences(of: "-", with: "")
            .replacingOccurrences(of: " ", with: "")
            .lowercased()
    }
    
    // MARK: - 持续监听下行消息
    private func receiveLoop() {
        webSocketTask?.receive { [weak self] result in
            guard let self = self else { return }
            Task { @MainActor in
                switch result {
                case .success(let message):
                    switch message {
                    case .data(let data):
                        self.parseIncomingMQTTData(data)
                    case .string(let str):
                        if let data = str.data(using: .utf8) {
                            self.parseIncomingMQTTData(data)
                        }
                    @unknown default:
                        break
                    }
                    self.receiveLoop()
                case .failure:
                    self.handleConnectionFailure()
                }
            }
        }
    }
    
    private func startPingLoop() {
        pingTimer?.invalidate()
        pingTimer = Timer.scheduledTimer(withTimeInterval: 20.0, repeats: true) { [weak self] _ in
            guard let self = self else { return }
            Task { @MainActor in
                // MQTT PINGREQ (0xC0, 0x00)
                let pingData = Data([0xC0, 0x00])
                self.webSocketTask?.send(.data(pingData)) { _ in }
            }
        }
    }
    
    private func scheduleReconnect() {
        reconnectTask?.cancel()
        reconnectTask = Task { @MainActor in
            try? await Task.sleep(nanoseconds: 2_500_000_000)
            guard !Task.isCancelled else { return }
            if !self.currentSubscribedID.isEmpty {
                self.connect(myDeviceID: self.currentSubscribedID)
            }
        }
    }
    
    // MARK: - 轻量级原生 MQTT 二进制封包与解包器
    private func buildMQTTConnectPacket(clientID: String) -> Data {
        var body = Data()
        body.append(contentsOf: [0x00, 0x04, 0x4D, 0x51, 0x54, 0x54])
        body.append(0x04)
        body.append(0x02)
        body.append(contentsOf: [0x00, 0x3C])
        let idBytes = Array(clientID.utf8)
        body.append(UInt8((idBytes.count >> 8) & 0xFF))
        body.append(UInt8(idBytes.count & 0xFF))
        body.append(contentsOf: idBytes)
        
        var packet = Data([0x10])
        packet.append(encodeRemainingLength(body.count))
        packet.append(body)
        return packet
    }
    
    private func buildMQTTSubscribePacket(topic: String, packetID: UInt16) -> Data {
        var body = Data()
        body.append(UInt8((packetID >> 8) & 0xFF))
        body.append(UInt8(packetID & 0xFF))
        
        let topicBytes = Array(topic.utf8)
        body.append(UInt8((topicBytes.count >> 8) & 0xFF))
        body.append(UInt8(topicBytes.count & 0xFF))
        body.append(contentsOf: topicBytes)
        body.append(0x00)
        
        var packet = Data([0x82])
        packet.append(encodeRemainingLength(body.count))
        packet.append(body)
        return packet
    }
    
    private func buildMQTTPublishPacket(topic: String, payload: Data) -> Data {
        var body = Data()
        let topicBytes = Array(topic.utf8)
        body.append(UInt8((topicBytes.count >> 8) & 0xFF))
        body.append(UInt8(topicBytes.count & 0xFF))
        body.append(contentsOf: topicBytes)
        body.append(payload)
        
        var packet = Data([0x30])
        packet.append(encodeRemainingLength(body.count))
        packet.append(body)
        return packet
    }
    
    private func encodeRemainingLength(_ length: Int) -> Data {
        var encoded = Data()
        var x = length
        repeat {
            var byte = UInt8(x % 128)
            x = x / 128
            if x > 0 { byte = byte | 128 }
            encoded.append(byte)
        } while x > 0
        return encoded
    }
    
    private func parseIncomingMQTTData(_ data: Data) {
        guard data.count >= 2 else { return }
        let bytes = [UInt8](data)
        let packetType = bytes[0] & 0xF0
        
        // 0x20 为 MQTT CONNACK 握手成功帧
        if packetType == 0x20 {
            onHandshakeConfirmed()
            return
        }
        
        // 0x30 为 MQTT PUBLISH 消息帧
        if packetType == 0x30 {
            var idx = 1
            var multiplier = 1
            var remainingLength = 0
            while idx < bytes.count {
                let encodedByte = bytes[idx]
                remainingLength += Int(encodedByte & 127) * multiplier
                multiplier *= 128
                idx += 1
                if (encodedByte & 128) == 0 { break }
            }
            
            guard idx + 2 <= bytes.count else { return }
            let topicLen = (Int(bytes[idx]) << 8) | Int(bytes[idx + 1])
            idx += 2 + topicLen
            
            let qos = (bytes[0] & 0x06) >> 1
            if qos > 0 { idx += 2 }
            
            guard idx < bytes.count else { return }
            let payloadData = Data(bytes[idx..<bytes.count])
            if let decoded = try? JSONDecoder().decode(IMNetworkPacket.self, from: payloadData) {
                self.onReceivePacket?(decoded)
            }
        }
    }
}
